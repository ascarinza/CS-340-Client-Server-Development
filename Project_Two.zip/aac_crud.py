from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelterCRUD(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, database, collection):

        # Connection parameters
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database
        COL = collection
    
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    # Create method to implement the C in CRUD
    def create(self, data):
        if data is not None:
            self.collection.insert_one(data)  # data should be dictionary  
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    # Read method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            cursor = self.collection.find(query)
            return list(cursor)
        else:
            raise Exception("Error querying documents.")
            return []
          
    # Update method to implement the U in CRUD
    def update(self, query, new_data):
        try:
            result = self.collection.update_many(query, {"$set": new_data})
            return result.modified_count
        except Exception as e:
            print("Error occured when updating")
            return 0
    
    # Delete method to implement the D in CRUD
    def delete(self, query):
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Error occured when deleting")
            return 0
